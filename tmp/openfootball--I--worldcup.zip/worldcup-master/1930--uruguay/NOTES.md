# World Cup 1930 Uruguay, 13 July - 30 July

- start_at: 1930-07-13

fix: add edition: or num:  e.g. num: 1 or edition: 1


## 13 Teams
- arg    # Argentina
- bra    # Brazil
- bol    # Bolivia
- chi    # Chile
- uru    # Uruguay
- per    # Peru
- par    # Paraguay
- mex    # Mexico
- usa    # United States
- fra    # France
- yug    # Yugoslavia (-2003)
- bel    # Belgium
- rou    # Romania

