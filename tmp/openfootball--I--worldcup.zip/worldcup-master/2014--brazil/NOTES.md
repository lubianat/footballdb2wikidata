#  World Cup 2014 Brazil

- start_at: 2014-06-12



## 32 Teams

- Europe (UEFA): 13 places
- Africa (CAF): 5 places
- Asia (AFC): 4 places
- South America (CONMEBOL) 5 places (+ Brazil qualified automatically as host nation for a total of 5 or 6 places)
- North, Central American and Caribbean (CONCACAF): 4 places
- Oceania (OFC): 0

see en.wikipedia.org/wiki/2014_FIFA_World_Cup_qualification

teams:
- Nigeria    -- Africa (5)
- Côte d'Ivoire
- Cameroon
- Ghana
- Algeria
- Australia   -- Asia (4) includes Australia
- Iran
- Japan
- South Korea
- Costa Rica   -- North, Central American and Caribbean (4)
- United States
- Honduras
- Mexico
- Brazil -- South America (5+1)
- Argentina
- Colombia
- Chile
- Ecuador
- Uruguay
- Belgium  -- Europe (13)
- Germany
- Italy
- Netherlands
- Switzerland
- Bosnia and Herzegovina
- Russia
- Spain
- England
- Greece
- Croatia
- Portugal
- France


## Grounds  - 12 stadiums/grounds
- maracana            , Rio de Janeiro, RJ
- nacionaldebrasilia  , Brasília, DF
- corinthians         , São Paulo, SP
- castelao            , Fortaleza, CE
- mineirao            , Belo Horizonte, MG
- fontenova           , Salvador, BA
- pantanal            , Cuiabá, MT
- amazonia            , Manaus, AM
- dasdunas            , Natal, RN
- beirario            , Porto Alegre, RS
- pernambuco          , Recife, PE
- dabaixada           , Curitiba, PR

## 12 cities:
- barsilia  etc

