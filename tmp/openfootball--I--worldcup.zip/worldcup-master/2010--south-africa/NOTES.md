#  World Cup 2010 South Africa


- fix: change time zone to ??
  - All times listed are South African Standard Time (UTC+02)  ???

- start_at: 2010-06-11


## Teams

```
##############
# Europa (13 team)
# Südamerika (5 teams)
# Nord- und Mittelamerika (3 teams)
# Afrika (6 teams)
# Asien mit Australien (4 teams)
# Ozeanien (1 team)

- den   # Dänemark  /// Europa
- ger   # Deutschland
- eng   # England
- fra   # Frankreich
- gre   # Griechenland
- ita   # Italien
- ned   # Niederlande
- por   # Portugal
- esp   # Spanien
- sui   # Schweiz
- srb   # Serbien
- svk   # Slowakei
- svn   # Slowenien
- arg   # Argentinien  /// Südamerika
- bra   # Brasilien
- chi   # Chile
- par   # Paraguay
- uru   # Uruguay
- mex   # Mexiko             /// Nord- und Mittelamerika
- usa   # Vereinigte Staaten
- hon   # Honduras
- alg   # Algerien          /// Afrika
- civ   # Elfenbeinküste
- gha   # Ghana
- cmr   # Kamerun
- nga   # Nigeria
- rsa   # Südafrika
- aus   # Australien  /// Asien mit Australien
- jpn   # Japan
- prk   # Nordkorea
- kor   # Südkorea
- nzl   # Neuseeland  /// Ozeanien
```
