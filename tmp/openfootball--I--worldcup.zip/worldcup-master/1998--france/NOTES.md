# World Cup 1998 France, 10 June - 12 July

- start_at: 1998-06-10


## 32 Teams

```
# -- Africa
- cmr # Cameroon
- mar # Morocco
- nga # Nigeria
- rsa # South Africa
- tun # Tunisia
# -- Asia
- irn # Iran
- jpn # Japan
- kor # South Korea
- ksa # Saudi Arabia
# -- Europe
- aut # Austria
- bel # Belgium
- bul # Bulgaria
- cro # Croatia
- den # Denmark
- eng # England
- fra # France
- ger # Germany
- ita # Italy
- ned # Netherlands
- nor # Norway
- rou # Romania
- sco # Scotland
- esp # Spain
- yug # Yugoslavia
# -- North and Central America
- jam # Jamaica
- mex # Mexico
- usa # USA
# -- South America
- arg # Argentina
- bra # Brazil
- chi # Chile
- col # Colombia
- par # Paraguay
```

