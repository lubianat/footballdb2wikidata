# World Cup 2002 in Korea n Japan, 31 May - 30 June

- start_at: 2002-05-31

## 32 Teams

```
# -- Africa
- cmr # Cameroon
- nga # Nigeria
- sen # Senegal
- rsa # South Africa
- tun # Tunisia
# -- Asia
- chn # China
- jpn # Japan
- kor # South Korea
- ksa # Saudi Arabia
# -- Europe
- bel # Belgium
- cro # Croatia
- den # Denmark
- eng # England
- fra # France
- ger # Germany
- ita # Italy
- pol # Poland
- por # Portugal
- irl # Ireland
- rus # Russia
- svn # Slovenia
- esp # Spain
- swe # Sweden
- tur # Turkey
# -- North and Central America
- crc # Costa Rica
- mex # Mexico
- usa # United States
# -- South America
- arg # Argentina
- bra # Brazil
- ecu # Ecuador
- par # Paraguay
- uru # Uruguay
```
