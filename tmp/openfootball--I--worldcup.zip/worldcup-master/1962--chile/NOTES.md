# World Cup 1962 Chile, 30 May - 17 June

- start_at: 1962-05-30
- fix: add edition: or num:  e.g. num: 7 or edition: 7

## 16 Teams

```
## Europe
- bul # Bulgaria
- tch # Czechoslovakia
- eng # England
- frg # West Germany
- hun # Hungary
- ita # Italy
- urs # Soviet Union
- esp # Spain
- sui # Switzerland
- yug # Yugoslavia
## North and Central America
- mex # Mexico
## South America
- arg # Argentina
- bra # Brazil
- chi # Chile
- col # Colombia
- uru # Uruguay
```

