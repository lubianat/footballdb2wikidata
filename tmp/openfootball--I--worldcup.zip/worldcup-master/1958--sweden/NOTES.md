# World Cup 1958 Sweden, 8 - 29 June

- start_at: 1958-06-08
- fix: add edition: or num:  e.g. num: 6 or edition: 6

## 16 Teams

```
## Europe
- aut # Austria
- tch # Czechoslovakia
- eng # England
- fra # France
- frg # West Germany
- hun # Hungary
- nir # Northern Ireland
- sco # Scotland
- urs # Soviet Union
- swe # Sweden
- wal # Wales
- yug # Yugoslavia
## North and Central America
- mex # Mexico
## South America
- arg # Argentina
- bra # Brazil
- par # Paraguay
```

