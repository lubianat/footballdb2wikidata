# World Cup 1974 West Germany, 13 June - 7 July

- start_at: 1974-06-13


## 16 Teams

```
# -- Africa
- zai # Zaire
# -- Asia
- aus # Australia
# -- Europe
- bul # Bulgaria
- frg # West Germany
- gdr # East Germany
- ita # Italy
- ned # Netherlands
- pol # Poland
- sco # Scotland
- swe # Sweden
- yug # Yugoslavia
# -- North and Central America
- hai # Haiti
# -- South America
- arg # Argentina
- bra # Brazil
- chi # Chile
- uru # Uruguay
```