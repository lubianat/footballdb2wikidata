#  World Cup 2006 Germany / Deutschland

- see en.wikipedia.org/wiki/2006_FIFA_World_Cup
-  www.fifa.com/worldcup/archive/germany2006

- fix: change time zone to ??
- All times listed are  ???

- start_at: 2006-06-09


## Teams

```
# Europa (UEFA) - 14
# Südamerika (CONMEBOL) - 4
# Nord- und Mittelamerika (CONCACAF) - 4
# Oceania (OFC) - 1
# Asien (AFC) - 4
# Afrika (CAF)  - 5

- cro   # Croatia  /// Europa (UEFA) - 14
- cze   # Czech Republic
- eng   # England
- fra   # France
- ger   # Deutschland
- ita   # Italien
- ned   # Niederlande
- pol   # Poland
- por   # Portugal
- srb   # Serbia and Montenegro
- esp   # Spanien
- swe   # Sweden
- sui   # Switzerland
- ukr   # Ukraine
- arg   # Argentinien       /// Südamerika (CONMEBOL) - 4
- bra   # Brasilien
- ecu   # Ecuador
- par   # Paraguay
- mex   # Mexiko             /// Nord- und Mittelamerika (CONCACAF) - 4
- usa   # Vereinigte Staaten
- crc   # Costa Rica
- tri   # Trinidad and Tobago
- aus   # Australien        /// Oceania (OFC) - 1
- jpn   # Japan             /// Asien (AFC) - 4
- kor   # Südkorea
- irn   # Iran
- ksa   # Saudi Arabia
- ang   # Angola          /// Afrika (CAF)  - 5
- civ   # Elfenbeinküste
- gha   # Ghana
- tog   # Togo
- tun   # Tunisia
```


