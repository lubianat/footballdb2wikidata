# World Cup 1982 Spain 13 June - 11 July

- start_at: 1982-06-13


## 24 Teams

```
## -- Africa
- alg # Algeria
- cmr # Cameroon
## -- Asia
- kuw # Kuwait
## -- Europe
- aut # Austria
- bel # Belgium
- tch # Czechoslovakia
- eng # England
- fra # France
- frg # West Germany
- hun # Hungary
- ita # Italy
- nir # Northern Ireland
- pol # Poland
- sco # Scotland
- urs # Soviet Union
- esp # Spain
- yug # Yugoslavia
## -- North and Central America
- slv # El Salvador
- hon # Honduras
## -- Oceania
- nzl # New Zealand
## -- South America
- arg # Argentina
- bra # Brazil
- chi # Chile
- per # Peru
```


