# World Cup 1938 France, 4 June - 19 June

- start_at: 1938-06-04
- fix: add edition: or num:  e.g. num: 3 or edition: 3

## 15 Teams

```
## Asia
- dei  # Dutch East Indies
## Europe
- bel  # Belgium
- tch  # Czechoslovakia
- fra  # France
- ger  # Germany
- hun  # Hungary
- ita  # Italy
- ned  # Netherlands
- nor  # Norway
- pol  # Poland
- rou  # Romania
- swe  # Sweden
- sui  # Switzerland
## North and Central America
- cub  # Cuba
## South America
- bra  # Brazil
```



