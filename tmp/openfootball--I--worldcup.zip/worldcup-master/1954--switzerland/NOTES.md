# World Cup 1954 Switzerland, 16 June - 4 July

- start_at: 1954-06-16
- fix: add edition: or num:  e.g. num: 5 or edition: 5

## 16 Teams

```
## Asia
- kor # Korea Republic
## Europe
- aut # Austria
- bel # Belgium
- tch # Czechoslovakia
- eng # England
- fra # France
- frg # West Germany
- hun # Hungary
- ita # Italy
- sco # Scotland
- sui # Switzerland
- tur # Turkey
- yug # Yugoslavia
## North and Central America
- mex # Mexico
## South America
- bra # Brazil
- uru # Uruguay
```

