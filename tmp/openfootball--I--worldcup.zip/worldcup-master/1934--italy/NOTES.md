# World Cup 1934 Italy, 27 May – 10 June

- start_at: 1934-05-27


fix: add edition: or num:  e.g. num: 2 or edition: 2

# 16 Teams
- arg # Argentina
- bra # Brazil
- usa # United States
- aut # Austria
- bel # Belgium
- swe # Sweden
- fra # France
- ger # Germany
- esp # Spain
- hun # Hungary
- sui # Switzerland
- ned # Netherlands
- ita # Italy
- tch # Czechoslovakia
- rou # Romania
- egy # Egypt
